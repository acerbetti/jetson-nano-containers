#! /usr/bin/python3.10
print '#coding=0'
